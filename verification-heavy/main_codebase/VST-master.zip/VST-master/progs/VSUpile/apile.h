void Apile_add(int n);
int Apile_count(void);

