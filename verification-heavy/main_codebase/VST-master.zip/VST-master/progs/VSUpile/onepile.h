void Onepile_init(void);
void Onepile_add(int n);
int Onepile_count(void);

