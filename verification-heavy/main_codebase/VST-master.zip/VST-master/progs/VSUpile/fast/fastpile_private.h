struct pile {
  int sum;
};

