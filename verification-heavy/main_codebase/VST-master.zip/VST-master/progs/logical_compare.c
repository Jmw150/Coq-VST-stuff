#include <stddef.h>

_Bool do_or (_Bool a, _Bool b) {
  return a || b;
}

_Bool do_and (_Bool a, _Bool b) {
  return a && b;
}


int main (void) {
  return 0;
}
